
class NetworkMonitor {
    constructor(blockList,whole_app_flag,front_end) {
        this.blockList = blockList;
        this.unaffiliated = whole_app_flag;
        this.front_end = front_end;
        
        var blockListLog = JSON.parse(JSON.stringify(blockList));
        for (var i = 0; i < blockListLog.length; ++i) {
            var item = blockListLog[i];
            if (item.query) {
                item.query = decryptData(item.query)
            }
            if (item.header) {
                item.header = decryptData(item.header)
            }
        }
        console.log(blockListLog);   
        //console.log(blockList);
            
    }

    trafficListener(request) {
        const url = request.url
        //console.log(url);
        const urlObject = new URL (url);
        var headers = {};
        if (request.requestHeaders) {
            for (let header of request.requestHeaders){
                headers[header.name.toLowerCase()] = header.value
            }
        }
        if(url) {
            const dummyA = document.createElement('a')
            dummyA.href = url
            const protocol = dummyA.protocol;
            const authority = dummyA.hostname;
            const path = dummyA.pathname;
            const method = request.method;
            const query = urlObject.search;
            var trie_auth = new Trie();
            var trie_path = new Trie();
            trie_auth.add_auth(authority);
            trie_path.add_path(path);
            let result = false;
            for (var i = 0; i < monitor.blockList.length; ++i) {
                var item = monitor.blockList[i];

                if(monitor.unaffiliated === true)
                {
                    if(authority.includes('www.'))
                    {
                         if(authority.replace('www.','') === item.authority && item.blocked === true)
                         {
                            result = true;
                            break;
                         }
                    }
                    else if(authority === item.authority && item.blocked === true)
                    {
                        result = true;
                        break;
                    }
                }
                else
                {
                    if (method.toLowerCase().match(item.method.toLowerCase()))
                    {
                        if (! trie_auth.isMatch_auth(item.authority))
                        {
                            continue;
                        }
                        
                        if (trie_path.isMatch_path(item.path))
                        {
                            if (this.front_end) {
                                if (item.query) {
                                    if (!checkQueriesMatch(query, item.query)) {
                                        continue
                                    }
                                }

                                if (item.header) {
                                    if (!checkHeadersMatch(headers, item.header)) {
                                        continue
                                    }
                                }
                            }
                            
                            
                            result = true;
                            break;
                        }

                        

                    }
                }
            }

            if(result) {
                console.log(url + " is blocked.")
                return {
                    cancel: true
                }
            }
        } else {
            return {
                cancel: true
            }
        }
    }

}

let monitor = null;

const monitorFn = function(data) {
    if (monitor !== null) {
        return monitor.trafficListener(data)
    }
}

const defaultFilter = { urls: ["*://*/*"] };
const webRequestEvents = [
    ["onAuthRequired", defaultFilter, ["blocking"]],
    ["onBeforeRequest", defaultFilter, ["blocking"]],
    ["onBeforeSendHeaders", defaultFilter, ["blocking", "requestHeaders", "extraHeaders"]],
]

function startMonitor(blockList,whole_app_flag,front_end) {
    console.log("Starting Monitor");

    monitor = new NetworkMonitor(blockList,whole_app_flag, front_end);

    webRequestEvents.forEach(([requestName, baseFilter, optArgs]) => {
        chrome.webRequest[requestName].addListener(
            monitorFn,
            baseFilter,
            optArgs
        )
    })
}

function removeMonitor() {
    chrome.webRequest.onCompleted.removeListener(monitorFn)
    chrome.webRequest.onSendHeaders.removeListener(monitorFn)
    monitor = null;
}

chrome.runtime.onMessage.addListener(function(message, sender, callback) {
    if(message.command === "Start") {
        startMonitor(message.block,message.whole_app_flag, message.front_end_flag)
        callback("Started Monitor")
    } else if (message.command === "Stop") {
        const stoppedMonitor = monitor;
        removeMonitor()
        callback("Stopped Monitor")
    }
});
