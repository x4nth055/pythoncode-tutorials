//const ROOT = '52.37.138.38'
const ROOT = 'ec2-54-212-122-234.us-west-2.compute.amazonaws.com'
//const ROOT = '127.0.0.1:5000'  // Local endpoint.

function stopMonitor() {
    chrome.runtime.sendMessage({command: "Stop"}, function(){})
}

const setWebApplications = function(response) {
    const selection = document.querySelector('#web_application')
    while (selection.firstChild) {
        selection.removeChild(selection.firstChild);
    }
    for (let web_application of response) {
        const option = document.createElement("option");
        option.value = web_application.id;
        option.textContent = web_application.name;

        selection.appendChild(option)
    }
    updateField('#web_application')
}

chrome.storage.local.get(["web_applications"], (result) => {
    if(result["web_applications"]) {
        setWebApplications(result["web_applications"])        
    } 

    fetch(`http://${ROOT}/web_applications`)
        .then(res => res.json())
        .then(response => chrome.storage.local.set(
            {"web_applications": response}, 
            () => setWebApplications(response)
        ));
})

const setWebFunctionClasses = function(response) {
    console.log(response);
    const selection = document.querySelector("#function_cat")
    while (selection.firstChild) {
        selection.removeChild(selection.firstChild);
    }
    if (response.length === 0) {
        console.log("No data found.");
        const option = document.createElement("option");
        option.value = -1;  // Use to indicate no data.
        option.textContent = "No data found";
        selection.appendChild(option);
    } else {
        for(let web_function of response) {
            const option = document.createElement("option");
            option.value = web_function.id;
            option.textContent = web_function.classification_name;
            selection.appendChild(option);
        }
    }
    selection.selectedIndex = "0";
    updateField('#function_cat');
}


chrome.storage.local.get(["web_function_classes", "check_box_value"], (result) => {
    console.log("Setting web_function_classes", result["web_function_classes"], result["check_box_value"])
    console.log(result.web_function_classes);
    if(result["web_function_classes"]){
        setWebFunctionClasses(result["web_function_classes"])
    } else {
        let web_application_id = result["#web_application"] ? result["#web_application"] : 100;  // set to first web app (DopBox) when no ID saved.
        let cr_only = result["check_box_value"] ? 1 : 0;
        console.log(`fetching function categories for id: ${web_application_id} and cr: ${cr_only}`);
        fetch(`http://${ROOT}/web_function_classes/app/${web_application_id}/${cr_only}`)
            .then(res => res.json())
            .then(result => {
                chrome.storage.local.set(
                {"web_function_classes": result}, 
                () => setWebFunctionClasses(result)
            )
            })
    }
})

// Saves the checkbox value.
const saveOptions = () => {
    chrome.storage.local.set({
        check_box_value: document.getElementById('committed_only').checked
    }, () => {
        console.log("Options saved.")
    })
}
 
// Restores all options (default is `false`).
const restoreOptions = () => {
    chrome.storage.local.get({
        check_box_value: false  // Default checked value.    
    }, (res) => {
        document.getElementById('committed_only').checked = res.check_box_value;
        chrome.storage.local.get(['monitorInProgress'], (result) => {
            toggleUI(result['monitorInProgress'])
        });
    });
}
 
document.addEventListener('DOMContentLoaded', restoreOptions);
document.querySelector('#committed_only').addEventListener('click', saveOptions);

function toggleUI(runningMonitor) {
    const cr_only = document.querySelector("#committed_only").checked
    var committed_only = cr_only ? " (committed resources only)" : " (committed + staged resources)"
    input_identifiers.forEach(identifier => document.querySelector(identifier).disabled = runningMonitor)
    // document.querySelector("#database_selector").disabled = runningMonitor
    document.querySelector("#stop").disabled = !runningMonitor
    document.querySelector("#start").disabled = runningMonitor
    document.querySelector("#committed_only").disabled = runningMonitor
    document.querySelector(".message").textContent = runningMonitor ? "Running" + committed_only: 'Press "Block" to filter web traffic';
    const update = { 'monitorInProgress': runningMonitor }
    chrome.storage.local.set(update, () => console.log("Successfully updated ", update))
}


async function onStartButtonClicked(event) {
    event.preventDefault()
    let unaffiliated = false;
    let frontend_flag = false;

    document.querySelector(".error").textContent = ""

    // Exit if user has not selected a function category.
    if (document.querySelector("#function_cat").value === "") {
        document.querySelector(".error").textContent = "Select a function category."
        return;
    }

    // Exit if no data available.
    if (Number(document.querySelector("#function_cat").value) === -1) {
        let msg = document.querySelector("#committed_only").checked ? "committed resources only" : " committed + staged resources";
        document.querySelector(".error").textContent = `No data for ${msg}`
        return;
    }

    const web_application_id = document.querySelector("#web_application").value;
    const web_function_id = document.querySelector("#function_cat").value;
    const database_select = document.querySelector("#database_selector").value;
    const cr_only = document.querySelector("#committed_only").checked;

    var cr_only_int = 0;
    if (cr_only == true) { 
        cr_only_int = 1;
    }
    
    let data = null;
    if (database_select == "back_end") {
        if(web_function_id == 1) {
            response = await fetch(`http://${ROOT}/whole_app/${web_application_id}`)
            unaffiliated = true;
        }
        else {
            response = await fetch(`http://${ROOT}/traffic/${web_application_id}/${web_function_id}/${cr_only_int}`)
        }

    }
    else {
        if(web_function_id == 1) {
            response = await fetch(`http://${ROOT}/whole_app/${web_application_id}`)
            unaffiliated = true;
        }
        else {
            response = await fetch(`http://${ROOT}/resolver/${web_application_id}/${web_function_id}`)
            frontend_flag = true;
        }
    }
    data = await response.json();


    console.log(data);
    if(data.length > 0) {
        chrome.runtime.sendMessage({ command: "Start", block: data, whole_app_flag: unaffiliated, front_end_flag: frontend_flag}, function(response) {
            toggleUI(true)
        })
    } 
    else {
        const web_app_sel = document.querySelector('#web_application')
        const web_app = web_app_sel.options[web_app_sel.selectedIndex].text
        const web_function_sel = document.querySelector("#function_cat")
        const web_function = web_function_sel.options[web_function_sel.selectedIndex].text
        console.log(web_app, web_function)
        document.querySelector(".error").textContent = `No Data found for ${web_app}-${web_function}`
    }
}

function onStopButtonClicked(event) {
    event.preventDefault()
    stopMonitor()
    toggleUI(false)
}

const syncField = (identifier) => (evt) => {
    evt.preventDefault()
    const val = evt.target.value;
    const update = {};
    update[identifier] = val
    chrome.storage.local.set(update, () => console.log(`Successfully updated ${identifier}`, val))
}

const input_identifiers = [
    "#function_cat",
    "#web_application",
    "#database_selector",
    "#committed_only"
]

const updateField = (identifier) => {
    chrome.storage.local.get([identifier], (result) => {
        if (result[identifier] !== undefined) {
            console.log(`Setting ${identifier} to ${result.identifier}`)
            document.querySelector(identifier).value = result[identifier]
        }
    });
}

chrome.storage.local.get(['monitorInProgress'], (result) => {
    toggleUI(result['monitorInProgress'])
})

const updateFields = function() {
    input_identifiers.forEach(
        identifier => updateField(identifier)
    )
}

updateFields()

function fetchFunctionClasses() {
    console.log('fetching function classes')
    let web_application_id = document.getElementById('web_application').value;
    let cr_only = document.getElementById('committed_only').checked ? 1 : 0;
    input_identifiers.forEach(id => document.querySelector(id).disabled = true)
    fetch(`http://${ROOT}/web_function_classes/app/${web_application_id}/${cr_only}`)
    .then(res => res.json())
    .then(result => {
        input_identifiers.forEach(id => document.querySelector(id).disabled = false)
        chrome.storage.local.set(
        {"web_function_classes": result}, 
        () => setWebFunctionClasses(result)
        )}).catch((err) => input_identifiers.forEach(id => document.querySelector(id).disabled = false));
}

input_identifiers.forEach(
    identifier => {
        console.log(`adding listener to ${identifier}`)
        if (["#web_application", "#committed_only"].includes(identifier)) {
            document.querySelector(identifier).addEventListener("change", syncField(identifier));

            // Listens for toggling commited resource check box/application changes from drop down.
            document.querySelector(identifier).addEventListener("change", fetchFunctionClasses);

        } else {
            document.querySelector(identifier).addEventListener("change", syncField(identifier))
        }
    }
)

const parseResponse = function(response) {
    
}

document.querySelector('#start').addEventListener('click', onStartButtonClicked);
document.querySelector('#stop').addEventListener('click', onStopButtonClicked);