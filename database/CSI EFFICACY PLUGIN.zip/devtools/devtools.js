const panels = [];

function handleShown() {
    console.log("panel is being shown");
  }
  
  function handleHidden() {
    console.log("panel is being hidden");
  }

panels.push(browser.devtools.panels.create(
    "CASB",                      // title
    "icons/border-48.png",                // icon
    "panel/panel.html"      // content
  ).then((newPanel) => {
    newPanel.onShown.addListener(handleShown);
    newPanel.onHidden.addListener(handleHidden);
  }));

browser.devtools.panels.onThemeChanged.addListener((newTheme) => {
    console.log("Theme changed", newTheme)

    panels.forEach(panel => console.log(panel.body))
})
