/// Sets the page theme to either dark or light mode
const setTheme = (theme) => {
    if (theme === "dark") {
        document.body.classList.add("darkMode")
    } else {
        document.body.classList.remove("darkMode")
    }
};

browser.devtools.panels.onThemeChanged.addListener(setTheme);
setTheme(browser.devtools.panels.themeName)

class EventListener {
    constructor() {
        this.listeners
    }

    addListener(listener) {
        this.listeners = this.listeners.concat(listener)
    }

    removeListener(listener) {
        this.listeners = this.listeners.filter(handler => listener !== handler)
    }

    trigger(...args) {
        this.listeners.forEach(listener => listener(...args))
    }
}

class NetworkMonitor {
    constructor() {
        this.traffic = []
    }

    listener(request) {
        console.log("Monitor listened to request", request)
        this.traffic.push(request)
    }

    get har() {
        return browser.devtools.network.getHAR()
    }

    publish(session, web_application, web_function_name, web_function_class_id) {
        console.log(session, web_application, web_function_class_id, web_function_name);
        console.log(this)

        this.har.then(har => {
            har.entries = this.traffic

            const pkg = {
                "session": session,
                "web_application_id": web_application,
                "web_function_id": web_function_class_id,
                "function_name": web_function_name,
                "har": har
            }

            const request = new XMLHttpRequest();
            request.open("POST", "http://localhost:5000/web_functions")
            request.setRequestHeader("Content-Type", "application/json")
            request.send(JSON.stringify(pkg))
        })
    }

    onDataReceived = new EventListener()
}


let monitor = null;

const browserListener = function(request) {
    if(monitor !== null) {
       monitor.listener(request) 
    }
}
browser.devtools.network.onRequestFinished.addListener(browserListener);

const startMonitor = function(e) {
    e.preventDefault()
    console.log("Starting Monitor...")
    monitor = new NetworkMonitor();

    console.log("Monitor started...")
}

async function stopMonitor(e) {
    e.preventDefault()

    if(monitor !== null) {
        browser.devtools.network.onRequestFinished.removeListener(monitor.listener)

        const session = document.querySelector("#session").value
        const web_application = document.querySelector("#web_application").value
        const function_name = document.querySelector("#function_name").value
        const function_category = document.querySelector("#function_cat").value
        monitor.publish(session, web_application, function_name, function_category)
    }

    monitor = null;
}

const getWebFunctions = function() {
    return fetch("http://localhost:5000/web_function_classes")
        .then(res => res.json())
}

getWebFunctions().then(response => {
    const selection = document.querySelector("#function_cat")
    for(let web_function of response) {
        const option = document.createElement("option");
        option.value = web_function.id
        option.textContent = web_function.classification_name

        selection.appendChild(option)
    }
})

const getWebApplications = () => fetch("http://localhost:5000/web_applications")
    .then(res => res.json());

getWebApplications().then(response => {
    console.log(response)
    const selection = document.querySelector('#web_application')
    for (let web_application of response) {
        const option = document.createElement("option");
        option.value = web_application.id;
        option.textContent = web_application.name;

        selection.appendChild(option)
    }
})



document.querySelector('#start').addEventListener('click', startMonitor);
document.querySelector('#stop').addEventListener('click', stopMonitor);