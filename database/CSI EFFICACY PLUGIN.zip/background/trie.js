
/* Trie Data Structure */

let Node = function() {
	this.keys = new Map();
	this.end = false;
	this.setEnd = function() {
		this.end = true;
	};
	this.isEnd = function() {
		return this.end;
	};
};

Array.prototype.subarray = function(start, end) {
	if (!end) { end = -1; } 
	return this.slice(start, this.length + 1 - (end * -1));
};

let Trie = function() {

	this.root = new Node();
	
	this.add = function(input, node = this.root) {
		if (input.length == 0) {
			node.setEnd();
			return;
		} else if (!node.keys.has(input[0])) {
			node.keys.set(input[0], new Node());
			return this.add(input.subarray(1,-1), node.keys.get(input[0]));
		} else {
			return this.add(input.subarray(1,-1), node.keys.get(input[0]));
		};
	};
	
	this.add_auth = function(auth, node = this.root) {
		let input =auth.split(/[.]/).filter(function (el) {
			return el != '';
		  });
		this.add(input);
	};

	this.add_path = function(path, node = this.root) {
		let input =path.split(/\//).filter(function (el) {
			return el != '';
		  });
		this.add(input);
	};
	this.isMatch_auth = function(auth) {
		let input =auth.split(/[.]/).filter(function (el) {
			return el != '';
		  });
		return this.isMatchLcpBeg(input);		
	}
	this.isMatch_path = function(path, node = this.root) {
		let input = path.split(/\//).filter(function (el) {
			return el != '';
		  });
		return this.isMatchLcpEnd(input);
	};

	this.isMatchLcpBeg = function(words, node = this.root) {
		if (words.length == 0)
			return true;
		
		if (node.isEnd())
		{
			return false;
		}

		var tf = false;
		for (const [key, value] of node.keys.entries()) {
			
			if (!this.isWildcardMatch(key, words[0])) {
				tf = this.isMatchLcpBeg(words, value);
			} else {
				tf = this.isMatchLcpBeg(words.subarray(1,-1), value);
			};

			node = value;
			if (tf)
			{
				if (words.length == 1)
					return node.isEnd();

				break;
			}
		}
		return tf			
	};
	this.isMatchLcpEnd = function(words) {
		let node = this.root;
		while (words.length > 0) {
			var tf = false;
			for (const [key, value] of node.keys.entries()) {
				// if not wildcard match, continue traversal
				if (!this.isWildcardMatch(key, words[0])) {
					continue;
				} else {
					node = value;
					words = words.subarray(1,-1);

					tf = true;
					break;
				};
			}

			if (!tf)
				return tf;			
		};

		return true;
	};

	// key - An encountered segment of a URL
	// word - A segment in the trie that might be wildcarded 
	this.isWildcardMatch = function(key, word) {
		// transform word into a regex to match against key 
		let regex = this.transform(word);
		if (key.match(regex)) {
			return true;
		}
		return false; 
	};

	// Transforms a word from our trie into a regular expression
	this.transform = function(word) {
		word = word.replace(/[.]/g, "[.]");
		word = word.replace(/\*/g, ".*");
		word = word.replace(/[(]/g, "[(]");
		word = word.replace(/[)]/g, "[)]")
		return word; 
	}

	this.print = function() {
		let words = new Array();
		let search = function(node, string) {
			if (node.keys.size != 0) {
				for (let letter of node.keys.keys()) {
					search(node.keys.get(letter), string.concat(letter," "));
				};
				if (node.isEnd()) {
					words.push(string.trimEnd());
				};
			} else {
				string.length > 0 ? words.push(string.trimEnd()) : undefined;
				return;
			};
		};
		search(this.root, new String());
		return words.length > 0 ? words : mo;
	};

};

let transform_resolver_data = function(word) {
	word = word.replace(/\\[.]/g, "[.]")
	return word; 
}





let checkHeadersMatch = function(trafficHeaders, encryptedHeaders) {
	var b64_RE = new RegExp('([A-Za-z0-9+/]+={0,2})', 'g');
	var result = encryptedHeaders
	var matched;
	do {
		matched = b64_RE.exec(encryptedHeaders);
		if (matched) {

			//decrypted data
			var decodedString = atob(matched[1]);

			var i = decodedString.indexOf('=');
			var [key, value]= [decodedString.slice(0,i), decodedString.slice(i+1)];
			key = key.toLocaleLowerCase()
			let regex = transform_resolver_data(value);
			if (trafficHeaders.hasOwnProperty(key) && trafficHeaders[key].match(regex)) {
				result = result.replace(matched[1], "true");
				//console.log(decodedString, "header is matched")
			}
			else{
				result = result.replace(matched[1], "false");
			}
		}
	} while (matched);

	result = result.toString().replace(/;/g, "||");
	result = result.toString().replace(/,/g, "&&");
	//console.log("checking:", result);
    return checkResult(result);
}

let checkResult = function (expression) { 
	return Function('"use strict"; return ' + expression)(); 
}


let checkQueriesMatch = function(trafficQueries, encryptedQueries) {
	var b64_RE = new RegExp('([A-Za-z0-9+/]+={0,2})', 'g');
	var result = encryptedQueries
	var matched;
	do {
		matched = b64_RE.exec(encryptedQueries);
		if (matched) {
			
			//decrypted data

			var decodedString = atob(matched[1]);

			let regex = transform_resolver_data(decodedString);
			let regexgWraper = `.*${regex}.*`;
			if (trafficQueries.match(regexgWraper)) {
				//console.log(decodedString, "query is matched")
				result = result.replace(matched[1], "true");
			}
			else{
				result = result.replace(matched[1], "false");
			}
		}
	} while (matched);

	result = result.toString().replace(/;/g, "||");
	result = result.toString().replace(/,/g, "&&");
	//console.log("checking:", result);
	return checkResult(result);
}

let decryptData = function (encryptedData) {
	var b64_RE = new RegExp('([A-Za-z0-9+/]+={0,2})', 'g');
	var result = encryptedData;
	do {
		matched = b64_RE.exec(encryptedData);
		if (matched) {
			var decodedString = atob(matched[1]);
			result = result.replace(matched[1], decodedString);
			
		}
	} while (matched);

	result = result.toString().replace(/;/g, "||");
	result = result.toString().replace(/,/g, "&&");
	return result;

}

let test = function() {
	let uri = 'assets.gdirung34.amazon.com';
	let uri2 = '7ddr7w.dm.files.1drv.com';
	let uri3 = 'docs.google.com';



	myTrie1 = new Trie();
	myTrie1.add_auth(uri);
	myTrie1.add_auth(uri2);

	auth = 'assets.*.amazon.com';
	console.log(myTrie1.isMatch_auth(auth));
	auth = '*.amazon.com'
	console.log(myTrie1.isMatch_auth(auth));
	auth = 'amazon.com.*'
	console.log(myTrie1.isMatch_auth(auth))

	auth = '7ddr7w.dm.files.1drv.com';
	console.log(myTrie1.isMatch_auth(auth));
	auth = 'dm.files.1drv.com'
	console.log(myTrie1.isMatch_auth(auth));
	auth = 'files.1drv.com'
	console.log(myTrie1.isMatch_auth(auth));
	auth = 'dm.files.1drv'
	console.log(myTrie1.isMatch_auth(auth));
	auth = 'dm.files.1drv.com.extra'
	console.log(myTrie1.isMatch_auth(auth));
	
	console.log("Path testing");
	path = "/a/wildcard/b/search/b";
	//path2 = "/static/document/client/js/24242784-client_js_prod_kix_app.js"
	path3 = "/static/document/client/js/3908443890-homescreen_binary_i18n_core.js"
	myTrie = new Trie()
	myTrie.add_path(path)
	myTrie.add_path(path3)
	myTrie.add_auth(uri3);

	myTrie.add_auth('sharepoint.com')
	
	path = "/a/*/b/search/*";
	console.log(myTrie.isMatch_path(path));
	
	path = "/a/*/b/search";
	console.log(myTrie.isMatch_path(path));
	
	path = "/a/*";
	console.log(myTrie.isMatch_path(path));

	path = "/*/b/search/*";
	console.log(myTrie.isMatch_path(path));

	path = "/a/*/b/search/extra";
	console.log(myTrie.isMatch_path(path));
	console.log(myTrie.isMatch_path('/static/document/client/js/*-client_js_prod_kix_app.js'))

	let testauth = 'm365x567903-my.sharepoint.com'
	let testpath = ''
	console.log(myTrie.isMatch_auth(testauth))
};

//test();


let testResolver = function() {
	let headers = {'origin' :'https://test.sharepoint.com/test'};
	let headers_2 = {'origin' :'https://testasharepointbcom/test'};
	let query = 'www.google.com/test?key1=val1&key2=(val2)&key3=val3.com&key4=val4-com';
	let regex_h1 = {'origin': 'https://.*\\.sharepoint\\.com.*'}
	let regex_h2 = {'test': 'https://.*\\.sharepoint\\.com/.*'}
	let regex_h3 = {'origin': 'https://.*\\.sharepoint\\.com.*', 'test': 'https://.*\\.google\\.com/.*'}
	let regex_h4 = {'test': 'https://.*\\.sharepoint\\.com.*', 'test1': 'https://.*\\.google\\.com/.*'}
	let regex_h5 = {'origin' :'https://test.sharepoint.com/test'};
	console.log(isMatch_headers(headers,regex_h1))
	console.log(isMatch_headers(headers,regex_h2))
	console.log(isMatch_header(headers,regex_h3))
	console.log(isMatch_header(headers,regex_h4))
	console.log(isMatch_headers(headers, {}))
	console.log(isMatch_header(headers, {}))
	console.log(isMatch_header(headers, regex_h5))
	console.log(isMatch_headers(headers, regex_h5))
	console.log(isMatch_headers(headers_2, regex_h5))
	console.log(isMatch_headers(headers_2, regex_h1))
	console.log("query")

	let regex_q1 = ["key1=val1"]
	let regex_q2 = ["key2=\\(val2\\)"]
	let regex_q3 = ["key3=val3\\.com"]
	let regex_q4 = ["key1=val2", "key2=\\(val2\\)"]
	let regex_q5 = ["key1=val2", "key2=val3"]
	let regex_q6 = ["key4=val4[-]com"]
	console.log(isMatch_queries(query,regex_q1))
	console.log(isMatch_queries(query,regex_q2))
	console.log(isMatch_queries(query,regex_q3))
	console.log(isMatch_query(query,regex_q4))
	console.log(isMatch_query(query,regex_q5))
	console.log(isMatch_queries(query,[]))
	console.log(isMatch_query(query,[]))
	console.log(isMatch_queries(query, regex_q6))
	
}



let testDecrptedResolver = function() {
	let headers = {'origin' :'https://test.sharepoint.com/test', 'key1': 'value1'};
	let regex_h1 = 'b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q'; //true
	let regex_h2 = 'dGVzdD1odHRwczovLy4qXC5zaGFyZXBvaW50XC5jb20vLio='; //false
	let regex_h3 = 'b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q,dGVzdD1odHRwczovLy4qXC5nb29nbGVcXC5jb20vLio=' //false
	let regex_h4 = 'b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q;dGVzdD1odHRwczovLy4qXC5nb29nbGVcXC5jb20vLio=' //true
	let regex_h5 = 'b3JpZ2luPWh0dHBzOi8vdGVzdFwuc2hhcmVwb2ludFwuY29tL3Rlc3Q='; //true
	let regex_h6 = 'b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q,a2V5MT12YWx1ZS4q' //true
	let regex_h7 = 'b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q,a2V5MT12YWx1ZTI=' //false
	let regex_h8 = 'b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q;a2V5MT12YWx1ZTI=' //true
	let regex_h9 = 'b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q,b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q,b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q'; //true
	let regex_h10 = 'b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q;b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q;b3JpZ2luPWh0dHBzOi8vLipcLnNoYXJlcG9pbnRcLmNvbS4q'; //true
	console.log(checkHeadersMatch(headers,regex_h1))
	console.log(checkHeadersMatch(headers,regex_h2))
	console.log(checkHeadersMatch(headers,regex_h3))
	console.log(checkHeadersMatch(headers,regex_h4))
	//console.log(checkHeadersMatch(headers, ""))
	console.log(checkHeadersMatch(headers, regex_h5))
	console.log(checkHeadersMatch(headers, regex_h6))
	console.log(checkHeadersMatch(headers, regex_h7))
	console.log(checkHeadersMatch(headers, regex_h8))
	console.log(checkHeadersMatch(headers, regex_h9))
	console.log(checkHeadersMatch(headers, regex_h10))



	console.log("query --------------------------------------------")

	let query = 'www.google.com/test?key1=val1&key2=(val2)&key3=val3.com&key4=val4-com';
	let regex_q1 = "a2V5MT12YWwx" //true
	let regex_q2 = "a2V5Mj1cKHZhbDJcKQ==" //true
	let regex_q3 = "a2V5Mz12YWwzXC5jb20=" //true
	let regex_q4 = "a2V5MT12YWwx;a2V5Mj1cXCh2YWwyXFwp" //true
	let regex_q5 = "a2V5MT12YWwy;a2V5Mj12YWwz" //false
	let regex_q6 = "a2V5MT12YWwx,a2V5Mj1cXCh2YWwyXFwp" //false
	let regex_q7 = "a2V5ND12YWw0Wy1dY29t"//true
	let regex_q8 = "a2V5MT0uKg==" //true
	let regex_q9 = "a2V5MT12YWwx,a2V5MT12YWwx,a2V5MT12YWwx" //true
	let regex_q10 = "a2V5MT12YWwx;a2V5MT12YWwx;a2V5MT12YWwx" //true

	console.log(checkQueriesMatch(query,regex_q1))
	console.log(checkQueriesMatch(query,regex_q2))
	console.log(checkQueriesMatch(query,regex_q3))
	console.log(checkQueriesMatch(query,regex_q4))
	console.log(checkQueriesMatch(query,regex_q5))
	//console.log(checkQueriesMatch(query,""))

	console.log(checkQueriesMatch(query, regex_q6))
	console.log(checkQueriesMatch(query, regex_q7))
	console.log(checkQueriesMatch(query, regex_q8))
	console.log(checkQueriesMatch(query, regex_q9))
	console.log(checkQueriesMatch(query, regex_q10))

}
//testDecrptedResolver();